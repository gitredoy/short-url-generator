@include('frontend.include.topbar')



<main id="main">

    @yield('frontend')

</main>
<!-- End #main -->

@include('frontend.include.footer')
