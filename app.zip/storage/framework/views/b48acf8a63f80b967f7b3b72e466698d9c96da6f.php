<input class="form-control m-1" readonly type="text" value="<?php echo e($url->short_url); ?>" id="myInput">
<button class=" btn btn-info m-1" onclick="myFunction()">Copy</button>
<button id="<?php echo e($url->id); ?>" onclick="customizeFunction(this.id)" class="btn btn-warning m-1" >Customize URL</button>
<?php /**PATH H:\Xampp2022\htdocs\short-url-app\resources\views/frontend/url/generated_url.blade.php ENDPATH**/ ?>