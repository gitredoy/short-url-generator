<h3>Total URL Clicks</h3>
<small style="color: deepskyblue;font-weight: bold;">The total number of clicks that your link
    <a target="_blank" href="{{$checkUrl->short_url}}" style="color: lavender;font-size: 16px;font-style: italic;">({{$checkUrl->short_url}}</a>)
    has received so far.
</small>
<h1 class="text-white">{{$checkUrl->hit_count}}</h1>
