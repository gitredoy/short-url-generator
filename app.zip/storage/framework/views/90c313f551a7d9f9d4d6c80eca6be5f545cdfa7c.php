<?php echo $__env->make('frontend.include.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<main id="main">

    <?php echo $__env->yieldContent('frontend'); ?>

</main>
<!-- End #main -->

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH H:\Xampp2022\htdocs\short-url-app\resources\views/frontend/master.blade.php ENDPATH**/ ?>