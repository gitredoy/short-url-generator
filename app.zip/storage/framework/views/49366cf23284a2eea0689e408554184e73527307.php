<h3>Total URL Clicks</h3>
<small style="color: deepskyblue;font-weight: bold;">The total number of clicks that your link
    <a target="_blank" href="<?php echo e($checkUrl->short_url); ?>" style="color: lavender;font-size: 16px;font-style: italic;">(<?php echo e($checkUrl->short_url); ?></a>)
    has received so far.
</small>
<h1 class="text-white"><?php echo e($checkUrl->hit_count); ?></h1>
<?php /**PATH H:\Xampp2022\htdocs\short-url-app\resources\views/frontend/url/click_count.blade.php ENDPATH**/ ?>